return {
    "echasnovski/mini.pairs",
    event = "VeryLazy",
    opts = {},
}

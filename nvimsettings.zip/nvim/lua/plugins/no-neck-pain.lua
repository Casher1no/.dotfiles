return {
	{
		"shortcuts/no-neck-pain.nvim",
		version = "*",
	},
}

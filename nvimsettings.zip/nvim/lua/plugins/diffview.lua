return {
    "sindrets/diffview.nvim",
    opts = {}
}
